Hello,

Thank for downloading TradeMark.


NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation:
https://www.paypal.me/jrohcreative

Link to purchase full version and commercial license: 
https://jrohcreative.com/premium/trademark

Please visit our store for more great fonts: 
https://jrohcreative.com/

And follow my instagram for update:
@jrohcreative

If there is a problem, question, or anything about my fonts, please sent an email to
support@jrohcreative.com


How to Enable OpenType Features in Word, Photoshop and Illustrator
https://goo.gl/KQmtKo


Thanks,

JROH Creative